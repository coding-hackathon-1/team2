"""my_project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
#This login page is created using the Django framework

#Code is to create the login page
urls.py
from django.contrib import admin
from django.urls import path, include
from django.views.generic.base import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),
    path('', TemplateView.as_view(template_name='home.html'), name='home'),


login.html
<h2>Login</h2>
<form method="post">
	{% csrf_token %}
	{{ form.as_p }}
	<button type="submit">Login</button>
</form>

{% extends 'base.html' %}

{% block title %}Login{% endblock %}

{% block content %}
<h2>Login</h2>
<form method="post">
  {% csrf_token %}
  {{ form.as_p }}
  <button type="submit">Login</button>
</form>
{% endblock %}


login_base.html
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		{% block title %} Housing Helper SF {% endblock %}
	</title>
</head>
<body>
	<main>
		{% block content %}
		{% endblock %}
	</main>
</body>
</html>


login_home.html
{% extends 'login_base.html' %}

{% block title %}Home{% endblock %}

{% block content %}
{% if user.is_authenticated %}
	Hi {{ user.username }}!
	<p><a href="{% url 'logout' %}">logout</a></p>
{ % else %}
	<p> You are not logged in</p>
	<a href="{% url 'login' %}">login</a>
{% endif %}
{% endblock %}

# from django.contrib import admin
# from django.urls import path

# urlpatterns = [
#     path('admin/', admin.site.urls),
# ]
