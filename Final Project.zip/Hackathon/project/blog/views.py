from django.shortcuts import render
from django.http import HttpResponse
from .models import Post

{'posts':Post.objects.all()}


# posts=[
# 	{
# 		'author':'Rui',
# 		'title':'Blog post 1',
# 		'content':'TEC 410 Summer 2019',
# 		'date': 'May 24, 2019'

# 	},
# 	{
# 		'author':'Rui',
# 		'title':'Blog post 2',
# 		'content':'Second post',
# 		'date':'May 24, 2019'

# 	}


# ]

def home(request):
	context={'posts':Post.objects.all()}
	return render(request, 'blog/home.html', context)


def Area_Finder(request):
	return render(request, 'blog/Area_Finder.html')

def Safety(request):
	return render(request, 'blog/Safety.html')



# def about(request):
# 	return HttpResponse('<h1>Blog About</h1>', {'title': 'About'})

def Overview(request):
	return render(request, 'blog/Overview.html')


def Links(request):
	return render(request, 'blog/Links.html')
