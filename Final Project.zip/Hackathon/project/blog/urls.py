from django.urls import path
from . import views

urlpatterns = [
	path('', views.home, name='blog-home'),
	path('Area_Finder/', views.Area_Finder, name='blog-Area_Finder'),
	path('Safety/', views.Safety, name='blog-Safety'),
	path('Overview/', views.Overview, name= 'blog-Overview'),
	path('Links/', views.Links, name= 'blog-Links'),

]